package entity

import (
	"time"

	"github.com/google/uuid"
)

type User struct {
	ID           uuid.UUID
	Name         string
	Email        string
	PasswordHash string
	Role         UserRole
	Active       bool
	CreatedAt    time.Time
	UpdatedAt    time.Time
}
