// Package wshub holds in-memory WebSocket connection and per-room subscription state.
// Presence (online/offline) is volatile: derived from per-user connection counts only; nothing is persisted.
// Which rooms receive presence notifications is decided outside this package (see PresenceUseCase + WSController).
package wshub

import (
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/gorilla/websocket"
)

// PresenceChange describes an online/offline transition for one user.
// Changed is true only when:
//   - the first active connection for that user opens (IsOnline=true), or
//   - the last active connection for that user closes (IsOnline=false).
//
// Additional tabs/devices (2nd, 3rd, … connection) do not set Changed; dropping to a non-zero count likewise does not.
type PresenceChange struct {
	Changed  bool
	UserID   uuid.UUID
	IsOnline bool
}

// ConnectionManager tracks connections by conn id, per-user connection counts, and which rooms each connection subscribes to.
// It performs room-scoped broadcast only to connections that have subscribed to that room.
// It does not access the DB, authorize membership, or format HTTP/JSON.
type ConnectionManager struct {
	mu sync.RWMutex
	// connID -> live client
	clients map[uuid.UUID]*wsClient
	// userID -> number of active WebSocket connections (tabs / devices)
	userConnCount map[uuid.UUID]int
	// roomID -> set of connIDs subscribed to that room
	roomSubs map[uuid.UUID]map[uuid.UUID]struct{}
}

type wsClient struct {
	connID uuid.UUID
	userID uuid.UUID
	conn   *websocket.Conn
	// writeMu serializes WriteMessage / WriteControl (gorilla/websocket requirement).
	writeMu sync.Mutex
	rooms   map[uuid.UUID]struct{}
}

// NewConnectionManager creates an empty manager.
func NewConnectionManager() *ConnectionManager {
	return &ConnectionManager{
		clients:       make(map[uuid.UUID]*wsClient),
		userConnCount: make(map[uuid.UUID]int),
		roomSubs:      make(map[uuid.UUID]map[uuid.UUID]struct{}),
	}
}

// Register binds a WebSocket to a user and returns a new connection id. Caller must call RemoveConn when the socket closes.
// If this is the user's first active connection, PresenceChange reports an online transition.
func (m *ConnectionManager) Register(userID uuid.UUID, conn *websocket.Conn) (connID uuid.UUID, change PresenceChange) {
	id := uuid.New()
	c := &wsClient{
		connID: id,
		userID: userID,
		conn:   conn,
		rooms:  make(map[uuid.UUID]struct{}),
	}
	m.mu.Lock()
	m.clients[id] = c
	before := m.userConnCount[userID]
	m.userConnCount[userID] = before + 1
	m.mu.Unlock()

	if before == 0 {
		change = PresenceChange{Changed: true, UserID: userID, IsOnline: true}
	}
	return id, change
}

// RemoveConn drops the connection and all room subscriptions. It does not close the underlying socket.
// If this was the user's last connection, PresenceChange reports an offline transition.
func (m *ConnectionManager) RemoveConn(connID uuid.UUID) (change PresenceChange) {
	m.mu.Lock()
	defer m.mu.Unlock()
	c, ok := m.clients[connID]
	if !ok {
		return PresenceChange{}
	}
	for roomID := range c.rooms {
		if subs, ok := m.roomSubs[roomID]; ok {
			delete(subs, connID)
			if len(subs) == 0 {
				delete(m.roomSubs, roomID)
			}
		}
	}
	delete(m.clients, connID)

	before := m.userConnCount[c.userID]
	if before <= 1 {
		delete(m.userConnCount, c.userID)
	} else {
		m.userConnCount[c.userID] = before - 1
	}
	if before == 1 {
		return PresenceChange{Changed: true, UserID: c.userID, IsOnline: false}
	}
	return PresenceChange{}
}

// Subscribe adds connID to roomID. No authorization here — caller must verify membership first.
func (m *ConnectionManager) Subscribe(connID, roomID uuid.UUID) {
	m.mu.Lock()
	defer m.mu.Unlock()
	c, ok := m.clients[connID]
	if !ok {
		return
	}
	c.rooms[roomID] = struct{}{}
	if m.roomSubs[roomID] == nil {
		m.roomSubs[roomID] = make(map[uuid.UUID]struct{})
	}
	m.roomSubs[roomID][connID] = struct{}{}
}

// Unsubscribe removes connID from roomID (idempotent).
func (m *ConnectionManager) Unsubscribe(connID, roomID uuid.UUID) {
	m.mu.Lock()
	defer m.mu.Unlock()
	c, ok := m.clients[connID]
	if !ok {
		return
	}
	delete(c.rooms, roomID)
	if subs, ok := m.roomSubs[roomID]; ok {
		delete(subs, connID)
		if len(subs) == 0 {
			delete(m.roomSubs, roomID)
		}
	}
}

// BroadcastToRoom sends a text payload to every subscriber of roomID. Failed writes are ignored per client.
func (m *ConnectionManager) BroadcastToRoom(roomID uuid.UUID, payload []byte) {
	m.mu.RLock()
	subs := m.roomSubs[roomID]
	if len(subs) == 0 {
		m.mu.RUnlock()
		return
	}
	list := make([]*wsClient, 0, len(subs))
	for cid := range subs {
		if c, ok := m.clients[cid]; ok {
			list = append(list, c)
		}
	}
	m.mu.RUnlock()

	for _, c := range list {
		c.writeMu.Lock()
		c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
		_ = c.conn.WriteMessage(websocket.TextMessage, payload)
		c.writeMu.Unlock()
	}
}

// BroadcastToUsersInRooms delivers payload once per connection that is subscribed to at least one of roomIDs.
// If the same connection is subscribed to several of those rooms, it still receives the payload only once
// (presence is user-scoped; message/read events continue to use BroadcastToRoom per room).
func (m *ConnectionManager) BroadcastToUsersInRooms(roomIDs []uuid.UUID, payload []byte) {
	if len(roomIDs) == 0 || len(payload) == 0 {
		return
	}
	m.mu.RLock()
	seen := make(map[uuid.UUID]struct{})
	var targets []*wsClient
	for _, rid := range roomIDs {
		subs := m.roomSubs[rid]
		for cid := range subs {
			if _, ok := seen[cid]; ok {
				continue
			}
			seen[cid] = struct{}{}
			if c, ok := m.clients[cid]; ok {
				targets = append(targets, c)
			}
		}
	}
	m.mu.RUnlock()

	for _, c := range targets {
		c.writeMu.Lock()
		c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
		_ = c.conn.WriteMessage(websocket.TextMessage, payload)
		c.writeMu.Unlock()
	}
}

// SendPing writes a WebSocket ping control frame. Returns false if the connection is gone or the write fails.
func (m *ConnectionManager) SendPing(connID uuid.UUID) bool {
	m.mu.RLock()
	c, ok := m.clients[connID]
	m.mu.RUnlock()
	if !ok {
		return false
	}
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	err := c.conn.WriteMessage(websocket.PingMessage, nil)
	return err == nil
}

// WriteText sends a single text frame with the same serialization rules as BroadcastToRoom (one writer at a time).
func (m *ConnectionManager) WriteText(connID uuid.UUID, payload []byte) bool {
	m.mu.RLock()
	c, ok := m.clients[connID]
	m.mu.RUnlock()
	if !ok {
		return false
	}
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	err := c.conn.WriteMessage(websocket.TextMessage, payload)
	return err == nil
}
